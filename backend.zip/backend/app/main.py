
"""LabGear Backend File 75 — FastAPI application and reservation API mounting.

Destination: backend/app/main.py (REPLACE the installed File 71).

Preserves the existing registration, login/session, Equipment Catalog, local
React CORS origins, and root status endpoint. Adds File 74's reservation router.

Importing this module only registers routes; it does not create or alter tables,
run migrations, create reservations, or send email/OTP messages.

Run from backend/:
    python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000

For authenticated local browser sessions, use matching hostnames:
    React:   http://localhost:5173
    FastAPI: http://localhost:8000
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes.equipment import router as equipment_router
from app.api.routes.login import router as login_router
from app.api.routes.registration import router as registration_router
from app.api.routes.reservations import router as reservations_router


app = FastAPI(
    title="LabGear API",
    description="School Laboratory Equipment Reservation System",
    version="1.0.0",
)

# Exact local Vite origins. Cookies are permitted for authenticated requests.
# CORS does not replace server-side authentication, authorization, or CSRF.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "X-CSRF-Token"],
)

# Registration (File 56): existing registration and email-verification routes.
app.include_router(registration_router)

# Login and sessions (File 63): existing password, CAPTCHA, email OTP,
# current-user, and logout routes. Keep the existing authentication flow.
app.include_router(login_router)

# Equipment Catalog (File 70): authenticated, read-only inventory endpoints.
app.include_router(equipment_router)

# Reservations (File 74): authenticated reservation creation and personal list.
app.include_router(reservations_router)


@app.get("/", tags=["System"])
def read_root() -> dict[str, str]:
    """Preserve the existing LabGear backend status response."""
    return {
        "message": "LabGear FastAPI backend is running",
        "status": "success",
    }
